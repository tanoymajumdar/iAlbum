import React from 'react';
import ReactDOM from 'react-dom';
import '../App.css';
import $ from 'jquery';

class Header extends React.Component{
    render(){
        return(
            <div>
                <h1> iAlbum </h1>
            </div>
        )
    }
}

export default Header;