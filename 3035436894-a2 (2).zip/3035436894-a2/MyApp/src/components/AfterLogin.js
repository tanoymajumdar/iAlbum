import React from 'react';
import ReactDOM from 'react-dom';
import '../App.css';
import $ from 'jquery';
//import GalleryAlbum from './GalleryAlbum'

class AfterLogin extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            user_id: '',
            username: this.props.username,
            friends: this.props.friendsList,
            albumID: '',
            photoToEnlarge: ''
        };
        // this.listFriends();
        this.handleGetPhotoMy = this.handleGetPhotoMy.bind(this)
        this.renderAlbum = this.renderAlbum.bind(this)
    }


    handleGetPhotoMy(e, i){
        e.preventDefault()
        let users = {}
        $.ajax({
            url: "http://localhost:3002/getalbum/"+0,
            type: "GET",
            data: users,
            dataType: 'json',
            xhrFields: {
                withCredentials: true
            },
            success: function (users) {
                    this.setState({
                        albumID : users._id
                    });
                     console.log(users)
            }.bind(this),
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }.bind(this)
        });
    }

    renderAlbum(string){
        let users = {}
        $.ajax({
            url: "http://localhost:3002/getalbum/"+ string,
            type: "GET",
            data: users,
            dataType: 'json',
            xhrFields: {
                withCredentials: true
            },
            success: function (users) {
                if (users['msg']) {
                    alert(users['msg']);
                } else {
                    this.setState({
                        albumID : users.userid
                    });
                    // console.log(users.url)
                }
            }.bind(this),
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }.bind(this)
        });
    }

    returnFriends(){
        let returnable = [];
        let stringHTML = [];
        for (let i = 0; i<this.props.friendsList.length; i++){
            returnable.push(this.props.friendsList[i].username);
        }
        for (let i = 0; i<returnable.length; i++){
            stringHTML.push(
                <p id = {this.props.friendsList[i]._id} onClick={this.handleGetPhotoMy}>{returnable[i]}'s Album</p>
            )
        }
        return stringHTML
        //return returnable;
    }

    render(){
        let this_copy = this;
        return(
            <div className = "sidenav">
                <p id={this.props.user_id} onClick={this.handleGetPhotoMy}> My Album </p>

                {/*{this.listFriends()}*/}
                {this.props.friendsList!=undefined?
                    this.returnFriends():
                    <p></p>}
            </div>
        )
    }
}

export default AfterLogin;