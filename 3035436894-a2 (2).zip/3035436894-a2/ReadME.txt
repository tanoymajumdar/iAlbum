--- READ ME TEXT ---

I have used various components which are stored in the components folder inside src folder

If there are changes made in the location of files my imports can go wrong and hence throw an error

--- !!! ---